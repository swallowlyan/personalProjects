package com.xieke.test.service;

import java.util.List;

import com.xieke.test.model.User;

public interface UserService {
	
	List<User> findAllUser();
}
