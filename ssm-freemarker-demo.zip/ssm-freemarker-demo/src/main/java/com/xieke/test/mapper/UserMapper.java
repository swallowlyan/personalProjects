package com.xieke.test.mapper;

import java.util.List;

import com.xieke.test.model.User;

/**
 * @author xieke
 *
 */
public interface UserMapper {
	List<User> findAllUser();
}
